from distutils.core import setup

setup(
    name='Supplies-of-Today',
    version='1.0',
    py_modules=['Supplies-of-Today']
)